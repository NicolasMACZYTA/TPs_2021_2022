Pour compiler, tapez "make".

Pour exécuter, lancez le programme "./exo1" puis saisissez (pressez entrée pour chaque entrée) :
12 2 +
12 2 + 3 -

Pour terminer, faites CRTL+D.