compilation : via le makefile fourni
execution : ./main_prog [fichier à éditer]

l'octet selectionné apparait surligné en cyan, et en blanc sa correspondance dans la fenetre adjascente 
F2 pour quitter


fonctionnel : 
- l'édition via caractère entré au clavier
- supression d'un octet
- navigation du fichier à l'aide de flèches

non fonctionnel : 
- edition hexadecimale
