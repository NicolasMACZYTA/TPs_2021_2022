compilation : via le makefile fourni
execution : ./main_prog



fonctionnel : 
- ncurses

non fonctionnel : 
- le reste
