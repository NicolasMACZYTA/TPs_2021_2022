compilation : javac *.java
execution : java Fournisseur
	    java Usine

utilisation : l'usine va envoyer au format texte le nom d'un produit. et le fournisseur va répondre si il l'a en stock et combien il en a ou si il ne le propose pas.
